/opt/ComposeFiles/prometheus/
 ├── prometheus-compose.yml
 ├── prometheus.yml
 ├── alertmanager.yml
 ├── provisioning/
 │ ├── dashboards/
 │ │ └── docker-dashboard.json
 │ └── dashboards.yml
 └── rules/
   └── basic-rules.yml